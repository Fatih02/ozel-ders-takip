import React, { useState } from "react";

export default function App() {
  const [lessons, setLessons] = useState([]);
  const [student, setStudent] = useState("");
  const [date, setDate] = useState("");
  const [topic, setTopic] = useState("");

  const addLesson = () => {
    if (student && date && topic) {
      setLessons([...lessons, { student, date, topic }]);
      setStudent("");
      setDate("");
      setTopic("");
    }
  };

  return (
    <div style={{ padding: "20px", fontFamily: "sans-serif" }}>
      <h1>📚 Özel Ders Takip</h1>

      <div style={{ marginBottom: "10px" }}>
        <input
          type="text"
          placeholder="Öğrenci Adı"
          value={student}
          onChange={(e) => setStudent(e.target.value)}
        />
        <input
          type="date"
          value={date}
          onChange={(e) => setDate(e.target.value)}
        />
        <input
          type="text"
          placeholder="Konu"
          value={topic}
          onChange={(e) => setTopic(e.target.value)}
        />
        <button onClick={addLesson}>Ekle</button>
      </div>

      <table border="1" cellPadding="5" style={{ width: "100%" }}>
        <thead>
          <tr>
            <th>Öğrenci</th>
            <th>Tarih</th>
            <th>Konu</th>
          </tr>
        </thead>
        <tbody>
          {lessons.map((lesson, index) => (
            <tr key={index}>
              <td>{lesson.student}</td>
              <td>{lesson.date}</td>
              <td>{lesson.topic}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
